require "import"
import "android.widget.*"
import "android.view.*"
import "android.graphics.Color"
import "android.content.DialogInterface"
import "android.content.Intent"
import "android.content.Context"
import "android.location.LocationManager"
import "android.location.LocationListener"
import "android.os.Handler"
import "android.os.Looper"

local updater = require "updater"

local windows = {}
local dlg = nil
local navStack = {}
local userData = { username = "" }
local activeEditTexts = {}
local savedUsername = ""
local showInlineWeather = false

local fetchedRealLocation = "Something went wrong"
local isFetchingData = false
local currentWeatherData = nil

local openWeatherApiKey = "1ee9a38dba7b169e42bdc3bbe78286d5"

local colorMap = {
  ["Black"]   = "#121212",
  ["Blue"]    = "#0D47A1",
  ["Brown"]   = "#3E2723",
  ["Cyan"]    = "#006064",
  ["Green"]   = "#1B5E20",
  ["Magenta"] = "#880E4F",
  ["Orange"]  = "#E65100",
  ["Pink"]    = "#880E4F",
  ["Purple"]  = "#4A148C",
  ["Red"]     = "#B71C1C",
  ["White"]   = "#E0E0E0",
  ["Yellow"]  = "#F57F17"
}

local colorNames = {
  "Black", "Blue", "Brown", "Cyan", "Green", "Magenta",
  "Orange", "Pink", "Purple", "Red", "White", "Yellow"
}

local currentThemeColor = "#0D47A1"
local currentSelectedColorName = "Blue"
local currentSoundEnabled = true
local currentSoundVolume = 100
local currentDetectLocationEnabled = true
local currentAutoReportEnabled = false
local currentAutoReportInterval = "5 minutes"
local currentForecastType = "Hourly forecast"
local currentTimeFormat = "24 Hours"

local tempSelectedColorName = "Blue"
local tempSoundEnabled = true
local tempSoundVolume = 100
local tempDetectLocationEnabled = true
local tempAutoReportEnabled = false
local tempAutoReportInterval = "5 minutes"
local tempForecastType = "Hourly forecast"
local tempTimeFormat = "24 Hours"

local currentPressUnit = "Hectopascals (hPa)"
local currentPrecipUnit = "Millimeters (mm)"
local currentTempUnit = "Celsius (°C)"
local currentVisUnit = "Kilometers"
local currentWindUnit = "Kilometers per hour (km/h)"

local tempPressUnit = "Hectopascals (hPa)"
local tempPrecipUnit = "Millimeters (mm)"
local tempTempUnit = "Celsius (°C)"
local tempVisUnit = "Kilometers"
local tempWindUnit = "Kilometers per hour (km/h)"

local currentWeatherReport = {
  air_quality = false,
  atmospheric_pressure = false,
  cloud_coverage = false,
  date = true,
  dew_point = false,
  feels_like_temperature = true,
  humidity = true,
  location = true,
  moonrise_time = false,
  moonset_time = false,
  rain_percentage = false,
  sunrise_time = false,
  sunset_time = false,
  temperature = true,
  time = true,
  uv_index = false,
  visibility = false,
  wind_direction = false,
  wind_speed = true
}

local tempWeatherReport = {
  air_quality = false,
  atmospheric_pressure = false,
  cloud_coverage = false,
  date = true,
  dew_point = false,
  feels_like_temperature = true,
  humidity = true,
  location = true,
  moonrise_time = false,
  moonset_time = false,
  rain_percentage = false,
  sunrise_time = false,
  sunset_time = false,
  temperature = true,
  time = true,
  uv_index = false,
  visibility = false,
  wind_direction = false,
  wind_speed = true
}

local showScreen

local prefs = service.getSharedPreferences("weather_app_prefs", Context.MODE_PRIVATE)

local function savePreferences()
  local editor = prefs.edit()
  editor.putString("username", savedUsername)
  editor.putString("selectedColorName", currentSelectedColorName)
  editor.putString("themeColor", currentThemeColor)
  editor.putBoolean("soundEnabled", currentSoundEnabled)
  editor.putInt("soundVolume", currentSoundVolume)
  editor.putBoolean("detectLocationEnabled", currentDetectLocationEnabled)
  editor.putBoolean("autoReportEnabled", currentAutoReportEnabled)
  editor.putString("autoReportInterval", currentAutoReportInterval)
  editor.putString("forecastType", currentForecastType)
  editor.putString("timeFormat", currentTimeFormat)

  editor.putString("pressUnit", currentPressUnit)
  editor.putString("precipUnit", currentPrecipUnit)
  editor.putString("tempUnit", currentTempUnit)
  editor.putString("visUnit", currentVisUnit)
  editor.putString("windUnit", currentWindUnit)

  for k, v in pairs(currentWeatherReport) do
    editor.putBoolean("report_" .. k, v)
  end
  editor.apply()
end

local function loadPreferences()
  savedUsername = prefs.getString("username", "")
  userData.username = savedUsername

  currentSelectedColorName = prefs.getString("selectedColorName", "Blue")
  tempSelectedColorName = currentSelectedColorName
  currentThemeColor = colorMap[currentSelectedColorName] or "#0D47A1"

  currentSoundEnabled = prefs.getBoolean("soundEnabled", true)
  tempSoundEnabled = currentSoundEnabled

  currentSoundVolume = prefs.getInt("soundVolume", 100)
  tempSoundVolume = currentSoundVolume

  currentDetectLocationEnabled = prefs.getBoolean("detectLocationEnabled", true)
  tempDetectLocationEnabled = currentDetectLocationEnabled

  currentAutoReportEnabled = prefs.getBoolean("autoReportEnabled", false)
  tempAutoReportEnabled = currentAutoReportEnabled

  currentAutoReportInterval = prefs.getString("autoReportInterval", "5 minutes")
  tempAutoReportInterval = currentAutoReportInterval

  currentForecastType = prefs.getString("forecastType", "Hourly forecast")
  tempForecastType = currentForecastType

  currentTimeFormat = prefs.getString("timeFormat", "24 Hours")
  tempTimeFormat = currentTimeFormat

  currentPressUnit = prefs.getString("pressUnit", "Hectopascals (hPa)")
  tempPressUnit = currentPressUnit

  currentPrecipUnit = prefs.getString("precipUnit", "Millimeters (mm)")
  tempPrecipUnit = currentPrecipUnit

  currentTempUnit = prefs.getString("tempUnit", "Celsius (°C)")
  tempTempUnit = currentTempUnit

  currentVisUnit = prefs.getString("visUnit", "Kilometers")
  tempVisUnit = currentVisUnit

  currentWindUnit = prefs.getString("windUnit", "Kilometers per hour (km/h)")
  tempWindUnit = currentWindUnit

  for k, v in pairs(currentWeatherReport) do
    local savedVal = prefs.getBoolean("report_" .. k, v)
    currentWeatherReport[k] = savedVal
    tempWeatherReport[k] = savedVal
  end
end

loadPreferences()

local function decodeUnicode(str)
  if not str then return "" end
  return str:gsub("\\u(%x%x%x%x)", function(h) 
    return utf8.char(tonumber(h, 16)) 
  end)
end

local function convertTemperature(celsius, unit)
  if unit == "Fahrenheit (°F)" then
    return string.format("%.1f °F", (celsius * 9 / 5) + 32)
  elseif unit == "Kelvin (K)" then
    return string.format("%.1f K", celsius + 273.15)
  else
    return string.format("%.1f °C", celsius)
  end
end

local function convertWindSpeed(ms, unit)
  if unit == "Kilometers per hour (km/h)" then
    return string.format("%.1f km/h", ms * 3.6)
  elseif unit == "Miles per hour (mph)" then
    return string.format("%.1f mph", ms * 2.23694)
  elseif unit == "Knots" then
    return string.format("%.1f knots", ms * 1.94384)
  else
    return string.format("%.1f m/s", ms)
  end
end

local function convertPressure(hpa, unit)
  if unit == "Atmosphere (atm)" then
    return string.format("%.3f atm", hpa / 1013.25)
  elseif unit == "Inches of Mercury (inHg)" then
    return string.format("%.2f inHg", hpa * 0.02953)
  elseif unit == "Millimeters of Mercury (mmHg)" then
    return string.format("%.1f mmHg", hpa * 0.750062)
  elseif unit == "Millibars (mbar)" or unit == "mbar" then
    return string.format("%d mbar", hpa)
  else
    return string.format("%d hPa", hpa)
  end
end

local function convertVisibility(meters, unit)
  if unit == "Kilometers" then
    return string.format("%.1f km", meters / 1000)
  elseif unit == "Miles" then
    return string.format("%.1f miles", meters / 1609.34)
  else
    return string.format("%d meters", meters)
  end
end

local function fetchLocationAndWeather(callback)
  local locationManager = service.getSystemService(Context.LOCATION_SERVICE)
  local isGpsEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
  local isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

  if not isGpsEnabled and not isNetworkEnabled then
    fetchedRealLocation = "Something went wrong"
    currentWeatherData = nil
    if callback then callback() end
    return
  end

  isFetchingData = true
  local isCompleted = false

  local listener
  local handler = Handler(Looper.getMainLooper())
  local timeoutRunnable

  local function finishProcess(success)
    if isCompleted then return end
    isCompleted = true

    if timeoutRunnable then
      handler.removeCallbacks(timeoutRunnable)
      timeoutRunnable = nil
    end

    if listener then
      pcall(function() locationManager.removeUpdates(listener) end)
      listener = nil
    end

    isFetchingData = false
    if not success then
      fetchedRealLocation = "Something went wrong"
      currentWeatherData = nil
    end
    if callback then callback() end
  end

  timeoutRunnable = Runnable{
    run = function()
      finishProcess(false)
    end
  }
  handler.postDelayed(timeoutRunnable, 10000)

  listener = LocationListener{
    onLocationChanged = function(location)
      local locObj = location
      if location and pcall(function() return location.get(0) end) then
        locObj = location.get(0)
      end

      if locObj and not isCompleted then
        local lat = locObj.getLatitude()
        local lng = locObj.getLongitude()

        local mapUrl = "https://nominatim.openstreetmap.org/reverse?format=json&accept-language=en&lat=" .. lat .. "&lon=" .. lng
        Http.get(mapUrl, nil, "UTF-8", {["User-Agent"] = "JieshuoWeatherApp/1.0"}, function(code, content)
          if isCompleted then return end

          if code == 200 and content then
            local streetName = content:match('"road"%s*:%s*"([^"]+)"')
              or content:match('"suburb"%s*:%s*"([^"]+)"')
              or content:match('"village"%s*:%s*"([^"]+)"')

            local townName = content:match('"city"%s*:%s*"([^"]+)"')
              or content:match('"town"%s*:%s*"([^"]+)"')

            streetName = decodeUnicode(streetName)
            townName = decodeUnicode(townName)

            if streetName ~= "" and townName ~= "" and streetName ~= townName then
              fetchedRealLocation = streetName .. ", " .. townName
            elseif townName ~= "" then
              fetchedRealLocation = townName
            elseif streetName ~= "" then
              fetchedRealLocation = streetName
            else
              fetchedRealLocation = "Something went wrong"
            end
          else
            fetchedRealLocation = "Something went wrong"
          end

          local weatherUrl = string.format("https://api.openweathermap.org/data/2.5/weather?lat=%f&lon=%f&units=metric&appid=%s", lat, lng, openWeatherApiKey)
          Http.get(weatherUrl, nil, "UTF-8", {}, function(wCode, wContent)
            if isCompleted then return end

            if wCode == 200 and wContent then
              pcall(function()
                local json = cjson or json
                if json then
                  currentWeatherData = json.decode(wContent)
                else
                  currentWeatherData = {
                    main = {
                      temp = tonumber(wContent:match('"temp"%s*:%s*([%d%.%-]+)') or 0),
                      feels_like = tonumber(wContent:match('"feels_like"%s*:%s*([%d%.%-]+)') or 0),
                      humidity = tonumber(wContent:match('"humidity"%s*:%s*(%d+)') or 0),
                      pressure = tonumber(wContent:match('"pressure"%s*:%s*(%d+)') or 1013)
                    },
                    wind = {
                      speed = tonumber(wContent:match('"speed"%s*:%s*([%d%.]+)') or 0),
                      deg = tonumber(wContent:match('"deg"%s*:%s*(%d+)') or 0)
                    },
                    clouds = {
                      all = tonumber(wContent:match('"all"%s*:%s*(%d+)') or 0)
                    },
                    visibility = tonumber(wContent:match('"visibility"%s*:%s*(%d+)') or 10000)
                  }
                end
              end)
              finishProcess(true)
            else
              finishProcess(false)
            end
          end)
        end)
      end
    end,
    onStatusChanged = function(provider, status, extras) end,
    onProviderEnabled = function(provider) end,
    onProviderDisabled = function(provider) end
  }

  if isGpsEnabled then
    locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, listener)
  end
  if isNetworkEnabled then
    locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 1000, 0, listener)
  end
end

local function hasGeneralSettingsChanged()
  return tempSelectedColorName ~= currentSelectedColorName or
         tempSoundEnabled ~= currentSoundEnabled or
         tempSoundVolume ~= currentSoundVolume or
         tempDetectLocationEnabled ~= currentDetectLocationEnabled or
         tempAutoReportEnabled ~= currentAutoReportEnabled or
         tempAutoReportInterval ~= currentAutoReportInterval or
         tempForecastType ~= currentForecastType or
         tempTimeFormat ~= currentTimeFormat
end

local function hasUnitSettingsChanged()
  return tempTempUnit ~= currentTempUnit or
         tempVisUnit ~= currentVisUnit or
         tempWindUnit ~= currentWindUnit or
         tempPressUnit ~= currentPressUnit or
         tempPrecipUnit ~= currentPrecipUnit
end

local function hasReportSettingsChanged()
  for k, v in pairs(tempWeatherReport) do
    if v ~= currentWeatherReport[k] then return true end
  end
  return false
end

local function getFormattedTime(formatType)
  local rawHour = tonumber(os.date("%H"))
  local minutes = os.date("%M")
  
  if formatType == "12 Hours" then
    return os.date("%I:%M")
  elseif formatType == "24 Hours" then
    local period = rawHour >= 12 and "PM" or "AM"
    local hour12 = rawHour % 12
    hour12 = hour12 == 0 and 12 or hour12
    return string.format("%02d:%s %s", hour12, minutes, period)
  elseif formatType == "Military Time" then
    return os.date("%H:%M")
  elseif formatType == "ISO Format" then
    return os.date("%Y-%m-%dT%H:%M:%S")
  else
    return os.date("%H:%M")
  end
end

local function getWeatherLines()
  if not currentDetectLocationEnabled or not currentWeatherData or fetchedRealLocation == "Something went wrong" then
    return { "Something went wrong" }
  end

  local lines = {}
  local main = currentWeatherData.main or {}
  local wind = currentWeatherData.wind or {}
  local clouds = currentWeatherData.clouds or {}

  if currentWeatherReport.date then table.insert(lines, "Date: " .. os.date("%Y-%m-%d")) end
  if currentWeatherReport.time then table.insert(lines, "Time: " .. getFormattedTime(currentTimeFormat)) end
  if currentWeatherReport.location then table.insert(lines, "Location: " .. fetchedRealLocation) end
  
  if currentWeatherReport.temperature and main.temp then
    table.insert(lines, "Temperature: " .. convertTemperature(main.temp, currentTempUnit))
  end
  if currentWeatherReport.feels_like_temperature and main.feels_like then
    table.insert(lines, "Feels Like: " .. convertTemperature(main.feels_like, currentTempUnit))
  end
  if currentWeatherReport.humidity and main.humidity then
    table.insert(lines, "Humidity: " .. main.humidity .. "%")
  end
  if currentWeatherReport.wind_speed and wind.speed then
    table.insert(lines, "Wind Speed: " .. convertWindSpeed(wind.speed, currentWindUnit))
  end
  if currentWeatherReport.atmospheric_pressure and main.pressure then
    table.insert(lines, "Atmospheric Pressure: " .. convertPressure(main.pressure, currentPressUnit))
  end
  if currentWeatherReport.visibility and currentWeatherData.visibility then
    table.insert(lines, "Visibility: " .. convertVisibility(currentWeatherData.visibility, currentVisUnit))
  end
  if currentWeatherReport.cloud_coverage and clouds.all then
    table.insert(lines, "Cloud Coverage: " .. clouds.all .. "%")
  end

  if #lines == 0 then
    table.insert(lines, "No details selected in settings.")
  end
  return lines
end

local function shareWeatherReport()
  local lines = getWeatherLines()
  local textToShare = table.concat(lines, "\n")
  
  local intent = Intent(Intent.ACTION_SEND)
  intent.setType("text/plain")
  intent.putExtra(Intent.EXTRA_TEXT, textToShare)
  
  local chooser = Intent.createChooser(intent, "Share Weather Report via")
  chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  
  if dlg then
    dlg.dismiss()
    dlg = nil
  end
  navStack = {}

  service.startActivity(chooser)
end

windows[1] = {
  title = "Excellent Weather Checker By Mahadeesh",
  elements = {
    { type = "title" },
    { type = "textview", text = "Welcome to the ultimate Weather experience!" },
    { type = "textview", text = "This extension brings you live, hyper-accurate weather forecasts," },
    { type = "textview", text = "Featuring advanced features designed to make checking conditions seamless," },
    { type = "textview", text = "And highly accessible for visually challenged persons." },
    { type = "button", label = "Exit", targetId = 0 },
    { type = "button", label = "Next Page", targetId = 2 }
  }
}

windows[2] = {
  title = "Enter your user name",
  elements = {
    { type = "title" },
    { type = "edittext", hint = "Enter your user name here", id = "username_input" },
    { type = "button", label = "Previous Page", targetId = 1 },
    { type = "button", label = "Next Page", targetId = 3 }
  }
}

windows[3] = {
  title = "Setup Complete",
  elements = {
    { type = "title" },
    { type = "textview", isWelcome = true, text = "" },
    { type = "button", label = "Finish", targetId = 4 }
  }
}

windows[4] = {
  title = "Excellent Weather Checker By Mahadeesh",
  elements = {
    { type = "title" },
    { type = "greeting" },
    { type = "button", label = "User Guide", targetId = 5 },
    { type = "button", label = "About & Credits", targetId = 6 },
    { type = "button", label = "Settings", targetId = 7 },
    { type = "button", isDynamicWeatherBtn = true },
    { type = "weather_report" },
    { type = "textview", isModeLabel = true, text = "" },
    { type = "button", label = "Exit", targetId = 0 }
  }
}

windows[5] = {
  title = "User Guide",
  elements = {
    { type = "title" },
    { type = "textview", text = "Welcome to the Complete Step-by-Step User Guide! Let us walk you through every room and feature of this app:" },
    { type = "textview", text = "--- STEP 1: INITIAL SETUP & USERNAME ---" },
    { type = "textview", text = "When you open this extension for the first time, Page 1 gives you a quick introduction. Tap 'Next Page' to reach Page 2, where you type your username into the edit box. Pressing 'Next Page' again saves your name and takes you to Page 3 (Setup Complete). Tap 'Finish' to jump right onto the Main Dashboard." },
    { type = "textview", text = "--- STEP 2: MAIN DASHBOARD & GREETINGS ---" },
    { type = "textview", text = "At the top of the Main Dashboard, you will hear a time-sensitive greeting (Good Morning, Good Afternoon, or Good Evening) followed by your saved username. Below the greeting, you have four main options: User Guide, About & Credits, Settings, and Check Weather." },
    { type = "textview", text = "--- STEP 3: CHECKING LIVE WEATHER ---" },
    { type = "textview", text = "Tap the 'Check Weather' button on the dashboard. A quick toast message 'Please wait...' will pop up while the app accesses your device GPS location and fetches accurate address details from OpenStreetMap and live weather metrics from OpenWeatherMap. Once fetched, all selected weather parameters (Temperature, Humidity, Wind, Location, etc.) will appear right on your screen line by line, perfectly formatted for screen readers." },
    { type = "textview", text = "--- STEP 4: SHARING YOUR WEATHER REPORT ---" },
    { type = "textview", text = "After fetching the weather, notice how the 'Check Weather' button dynamically transforms into 'Share Weather Report'! Tapping this button opens your Android system sharing menu, allowing you to send the full text report to friends via WhatsApp, SMS, Email, or social apps with a single click." },
    { type = "textview", text = "--- STEP 5: EXPLORING GENERAL SETTINGS ---" },
    { type = "textview", text = "In Main Dashboard -> Settings -> General Settings, you can configure overall app behavior:" },
    { type = "textview", text = "• Change Username: Tap this button to update your profile name anytime." },
    { type = "textview", text = "• Automatic Weather Report Interval: Check this box to enable recurring automatic updates, then pick your interval (from 5 minutes up to 1 hour)." },
    { type = "textview", text = "• Sound Effects & Volume: Enable or disable sound effects and adjust volume with the slider." },
    { type = "textview", text = "• Detect My Location: Keep this checked to auto-detect location via GPS. Unchecking it turns off location fetching." },
    { type = "textview", text = "• Select Colour: Change the entire screen background color (Blue, Green, Red, Black, White, etc.)." },
    { type = "textview", text = "• Time Format & Forecast Type: Choose between 12-Hour, 24-Hour, Military, or ISO time formats, and set your desired forecast period." },
    { type = "textview", text = "--- STEP 6: CUSTOMIZING UNIT SETTINGS ---" },
    { type = "textview", text = "In Main Dashboard -> Settings -> Unit Settings, tailor all scientific units to your preference:" },
    { type = "textview", text = "• Temperature: Switch between Celsius (°C), Fahrenheit (°F), and Kelvin (K)." },
    { type = "textview", text = "• Wind Speed: Select km/h, m/s, mph, Knots, or Beaufort scale." },
    { type = "textview", text = "• Atmospheric Pressure: Select hPa, atm, inHg, mmHg, or mbar." },
    { type = "textview", text = "• Visibility & Precipitation: Choose between Kilometers, Miles, Meters, Millimeters, Inches, or Centimeters." },
    { type = "textview", text = "--- STEP 7: WEATHER REPORT CONTENTS SETTINGS ---" },
    { type = "textview", text = "In Main Dashboard -> Settings -> Weather Report Contents Settings, you have full control over what goes into your weather report! Simply check or uncheck individual items (Air Quality, Atmospheric Pressure, Cloud Coverage, Date, Dew Point, Feels Like, Humidity, Location, Sunrise/Sunset, Rain %, Temperature, Time, UV Index, Visibility, Wind Speed & Direction). Only the parameters you select will be displayed and read aloud." },
    { type = "textview", text = "--- STEP 8: SAVING OR CANCELING CHANGES ---" },
    { type = "textview", text = "In every settings screen, make sure to tap the 'Save' button at the bottom to store your choices into app memory. If you change your mind, tap 'Cancel' to restore your previous settings without saving." },
    { type = "button", label = "Got It", targetId = 4 }
  }
}

windows[6] = {
  title = "About & Credits",
  elements = {
    { type = "title" },
    { type = "textview", text = "Here are the names of all those who helped make this project a success" },
    { type = "textview", text = "Developed By:" },
    { type = "textview", text = "Mahadeesh" },
    { type = "textview", text = "Helped By:" },
    { type = "textview", text = "Moosa Zaib" },
    { type = "textview", text = "Sound Designed By:" },
    { type = "textview", text = "20 20" },
    { type = "textview", text = "Tested By:" },
    { type = "textview", text = "50 50" },
    { type = "button", label = "Okay", targetId = 4 }
  }
}

windows[7] = {
  title = "Settings",
  elements = {
    { type = "title" },
    { type = "button", label = "General Settings", targetId = 9 },
    { type = "button", label = "Unit Settings", targetId = 11 },
    { type = "button", label = "Weather Report Contents Settings", targetId = 12 },
    { type = "button", label = "Back", targetId = 4 }
  }
}

windows[9] = {
  title = "General Settings",
  elements = {
    { type = "title" },
    { type = "button", label = "Change Username", targetId = 10 },
    { type = "checkbox", label = "Automatic weather report interval", field = "auto_report" },
    { type = "combobox", label = "Select interval", options = "5 minutes, 10 minutes, 15 minutes, 20 minutes, 25 minutes, 30 minutes, 35 minutes, 40 minutes, 45 minutes, 50 minutes, 55 minutes, 1 hour", unitType = "interval" },
    { type = "checkbox", label = "Enable Sound Effects", field = "sound" },
    { type = "slider", label = "Sound Effects Volume" },
    { type = "checkbox", label = "Detect My Location", field = "detect_location" },
    { type = "combobox", label = "Select Colour" },
    { type = "combobox", label = "Select Time Format", options = "12 Hours, 24 Hours, Military Time, ISO Format", unitType = "timeformat" },
    { type = "combobox", label = "Select forecast type", options = "Hourly forecast, 12 hours forecast, 24 hours forecast, 3 days forecast, 7 days forecast, 10 days forecast", unitType = "forecast" },
    { type = "button", label = "Cancel", isCancelBtn = true },
    { type = "button", label = "Save", isSaveBtn = true }
  }
}

windows[10] = {
  title = "Enter your new user name",
  elements = {
    { type = "title" },
    { type = "edittext", hint = "Enter your new user name here", id = "new_username_input" },
    { type = "button", label = "Cancel", targetId = 9 },
    { type = "button", label = "Update Username", isUpdateUserBtn = true }
  }
}

windows[11] = {
  title = "Unit Settings",
  elements = {
    { type = "title" },
    { type = "combobox", label = "Select Atmospheric Pressure Unit", options = "Atmosphere (atm), Hectopascals (hPa), Inches of Mercury (inHg), Millimeters of Mercury (mmHg), Millibars (mbar)", unitType = "press" },
    { type = "combobox", label = "Select Precipitation Unit", options = "Centimeters (cm), Inches (in), Millimeters (mm)", unitType = "precip" },
    { type = "combobox", label = "Select Temperature Unit", options = "Celsius (°C), Fahrenheit (°F), Kelvin (K)", unitType = "temp" },
    { type = "combobox", label = "Select Visibility Unit", options = "Kilometers, Miles, Meters", unitType = "vis" },
    { type = "combobox", label = "Select Wind Speed Unit", options = "Beaufort, Kilometers per hour (km/h), Meters per second (m/s), Miles per hour (mph), Knots", unitType = "wind" },
    { type = "button", label = "Cancel", isUnitCancelBtn = true },
    { type = "button", label = "Save", isUnitSaveBtn = true }
  }
}

windows[12] = {
  title = "Weather report contents settings",
  elements = {
    { type = "title" },
    { type = "textview", text = "Choose which weather details to hear in the announcements." },
    { type = "checkbox", label = "Air quality when available", reportKey = "air_quality" },
    { type = "checkbox", label = "Atmospheric pressure", reportKey = "atmospheric_pressure" },
    { type = "checkbox", label = "Cloud coverage", reportKey = "cloud_coverage" },
    { type = "checkbox", label = "Date", reportKey = "date" },
    { type = "checkbox", label = "Dew point", reportKey = "dew_point" },
    { type = "checkbox", label = "Feels like temperature", reportKey = "feels_like_temperature" },
    { type = "checkbox", label = "Humidity", reportKey = "humidity" },
    { type = "checkbox", label = "Location", reportKey = "location" },
    { type = "checkbox", label = "Moonrise time", reportKey = "moonrise_time" },
    { type = "checkbox", label = "Moonset time", reportKey = "moonset_time" },
    { type = "checkbox", label = "Rain percentage", reportKey = "rain_percentage" },
    { type = "checkbox", label = "Sunrise time", reportKey = "sunrise_time" },
    { type = "checkbox", label = "Sunset time", reportKey = "sunset_time" },
    { type = "checkbox", label = "Temperature", reportKey = "temperature" },
    { type = "checkbox", label = "Time", reportKey = "time" },
    { type = "checkbox", label = "UV Index", reportKey = "uv_index" },
    { type = "checkbox", label = "Visibility", reportKey = "visibility" },
    { type = "checkbox", label = "Wind direction", reportKey = "wind_direction" },
    { type = "checkbox", label = "Wind speed", reportKey = "wind_speed" },
    { type = "button", label = "Cancel", isReportCancelBtn = true },
    { type = "button", label = "Save", isReportSaveBtn = true }
  }
}

local function goBack()
  if #navStack > 1 then
    table.remove(navStack)
    local prevId = navStack[#navStack]
    showScreen(prevId, true)
  else
    if dlg then 
      dlg.dismiss() 
      dlg = nil
    end
    navStack = {}
  end
end

showScreen = function(id, isBack)
  local winData = windows[id]
  if not winData then return end

  if not isBack then
    if #navStack == 0 or navStack[#navStack] ~= id then
      table.insert(navStack, id)
    end
  end

  activeEditTexts = {}

  local themeColorParsed = Color.parseColor(currentThemeColor)
  local textColor = (currentThemeColor == "#E0E0E0") and Color.BLACK or Color.WHITE

  local layout = {
    LinearLayout,
    orientation = "vertical",
    layout_width = "fill",
    layout_height = "fill",
    backgroundColor = themeColorParsed,
    padding = "16dp",
    {
      ScrollView,
      layout_width = "fill",
      layout_height = "fill",
      fillViewport = true,
      backgroundColor = themeColorParsed,
      {
        LinearLayout,
        id = "container",
        orientation = "vertical",
        layout_width = "fill",
        layout_height = "wrap",
        backgroundColor = themeColorParsed,
      }
    }
  }

  if dlg then dlg.dismiss() end
  dlg = LuaDialog(service)
  dlg.View = loadlayout(layout)

  local intervalLabelView = nil
  local intervalSpinnerView = nil

  for _, elem in ipairs(winData.elements) do
    if elem.type == "title" then
      local t = TextView(service)
      t.setText(winData.title)
      t.setTextSize(20)
      t.setTextColor(textColor)
      t.setPadding(10, 10, 10, 10)
      t.setFocusable(true)
      t.setFocusableInTouchMode(true)
      container.addView(t)
      t.requestFocus()

    elseif elem.type == "greeting" then
      local t = TextView(service)
      local currentHour = tonumber(os.date("%H"))
      local greetingPrefix = (currentHour < 12 and "Good Morning ") or (currentHour < 17 and "Good Afternoon ") or "Good Evening "
      local nameToShow = (savedUsername ~= "" and savedUsername) or "User"
      t.setText(greetingPrefix .. nameToShow)
      t.setTextSize(18)
      t.setTextColor(textColor)
      t.setPadding(10, 5, 10, 15)
      t.setFocusable(true)
      container.addView(t)

    elseif elem.type == "weather_report" then
      if id == 4 and showInlineWeather then
        local lines = getWeatherLines()
        for _, lineText in ipairs(lines) do
          local t = TextView(service)
          t.setText(lineText)
          if not currentDetectLocationEnabled or lineText:find("wrong") then
            t.setTextColor(Color.RED)
          else
            t.setTextColor(textColor)
          end
          t.setTextSize(16)
          t.setPadding(10, 4, 10, 4)
          t.setFocusable(true)
          container.addView(t)
        end
      end

    elseif elem.type == "edittext" then
      local e = EditText(service)
      e.setHint(elem.hint)
      e.setHintTextColor(Color.GRAY)
      e.setTextColor(textColor)
      if id == 2 and savedUsername ~= "" then e.setText(savedUsername) end
      if elem.id then activeEditTexts[elem.id] = e end
      container.addView(e)

    elseif elem.type == "checkbox" then
      local cb = CheckBox(service)
      cb.setText(elem.label)
      cb.setTextColor(textColor)

      if elem.field == "detect_location" then cb.setChecked(tempDetectLocationEnabled)
      elseif elem.field == "auto_report" then cb.setChecked(tempAutoReportEnabled)
      elseif elem.field == "sound" then cb.setChecked(tempSoundEnabled)
      elseif elem.reportKey then cb.setChecked(tempWeatherReport[elem.reportKey] or false) end

      cb.setOnCheckedChangeListener({
        onCheckedChanged = function(buttonView, isChecked)
          if elem.field == "detect_location" then tempDetectLocationEnabled = isChecked
          elseif elem.field == "auto_report" then
            tempAutoReportEnabled = isChecked
            if intervalLabelView and intervalSpinnerView then
              local vis = isChecked and View.VISIBLE or View.GONE
              intervalLabelView.setVisibility(vis)
              intervalSpinnerView.setVisibility(vis)
            end
          elseif elem.field == "sound" then tempSoundEnabled = isChecked
          elseif elem.reportKey then tempWeatherReport[elem.reportKey] = isChecked end
        end
      })
      container.addView(cb)

    elseif elem.type == "slider" then
      if elem.label and elem.label ~= "" then
        local t = TextView(service)
        t.setText(elem.label)
        t.setTextColor(textColor)
        t.setFocusable(true)
        container.addView(t)
      end
      local sb = SeekBar(service)
      sb.setMax(100)
      sb.setProgress(tempSoundVolume)
      sb.setOnSeekBarChangeListener({
        onProgressChanged = function(seekBar, progress, fromUser)
          if fromUser then tempSoundVolume = progress end
        end
      })
      container.addView(sb)

    elseif elem.type == "combobox" then
      local t = nil
      if elem.label and elem.label ~= "" then
        t = TextView(service)
        t.setText(elem.label)
        t.setTextColor(textColor)
        t.setFocusable(true)
        container.addView(t)
      end
      local sp = Spinner(service)

      local opts = {}
      if elem.options then
        for opt in string.gmatch(elem.options or "", "[^,]+") do
          local trimmed = opt:match("^%s*(.-)%s*$")
          if trimmed ~= "" then table.insert(opts, trimmed) end
        end
      else
        opts = colorNames
      end

      local adapter = ArrayAdapter(service, android.R.layout.simple_spinner_item, opts)
      adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
      sp.setAdapter(adapter)

      if elem.unitType then
        local targetVal = ""
        if elem.unitType == "temp" then targetVal = tempTempUnit
        elseif elem.unitType == "vis" then targetVal = tempVisUnit
        elseif elem.unitType == "wind" then targetVal = tempWindUnit
        elseif elem.unitType == "press" then targetVal = tempPressUnit
        elseif elem.unitType == "precip" then targetVal = tempPrecipUnit
        elseif elem.unitType == "interval" then targetVal = tempAutoReportInterval
        elseif elem.unitType == "forecast" then targetVal = tempForecastType
        elseif elem.unitType == "timeformat" then targetVal = tempTimeFormat end

        for idx, val in ipairs(opts) do
          if val == targetVal then
            sp.setSelection(idx - 1)
            break
          end
        end

        sp.setOnItemSelectedListener(AdapterView.OnItemSelectedListener{
          onItemSelected = function(parent, view, position, id)
            local selected = opts[position + 1]
            if elem.unitType == "temp" then tempTempUnit = selected
            elseif elem.unitType == "vis" then tempVisUnit = selected
            elseif elem.unitType == "wind" then tempWindUnit = selected
            elseif elem.unitType == "press" then tempPressUnit = selected
            elseif elem.unitType == "precip" then tempPrecipUnit = selected
            elseif elem.unitType == "interval" then tempAutoReportInterval = selected
            elseif elem.unitType == "forecast" then tempForecastType = selected
            elseif elem.unitType == "timeformat" then tempTimeFormat = selected end
          end
        })

        if elem.unitType == "interval" then
          intervalLabelView = t
          intervalSpinnerView = sp
          local vis = tempAutoReportEnabled and View.VISIBLE or View.GONE
          if intervalLabelView then intervalLabelView.setVisibility(vis) end
          intervalSpinnerView.setVisibility(vis)
        end
      else
        for idx, name in ipairs(colorNames) do
          if name == tempSelectedColorName then
            sp.setSelection(idx - 1)
            break
          end
        end

        sp.setOnItemSelectedListener(AdapterView.OnItemSelectedListener{
          onItemSelected = function(parent, view, position, id)
            tempSelectedColorName = colorNames[position + 1]
          end
        })
      end
      container.addView(sp)

    elseif elem.type == "button" then
      local b = Button(service)
      
      if elem.isDynamicWeatherBtn then
        b.setText(showInlineWeather and "Share Weather Report" or "Check Weather")
      else
        b.setText(elem.label)
      end
      
      b.setAllCaps(false)
      b.setTextColor(textColor)
      b.setOnClickListener(function()
        if elem.isDynamicWeatherBtn then
          if not showInlineWeather then
            showInlineWeather = true
            if currentDetectLocationEnabled then
              pcall(function() Toast.makeText(service, "Please wait...", Toast.LENGTH_SHORT).show() end)
              fetchLocationAndWeather(function()
                showScreen(4, true)
              end)
            else
              showScreen(4, true)
            end
          else
            shareWeatherReport()
          end
          return
        end

        if elem.isSaveBtn then
          local isChanged = hasGeneralSettingsChanged()
          currentSelectedColorName = tempSelectedColorName
          currentSoundEnabled = tempSoundEnabled
          currentSoundVolume = tempSoundVolume
          currentDetectLocationEnabled = tempDetectLocationEnabled
          currentAutoReportEnabled = tempAutoReportEnabled
          currentAutoReportInterval = tempAutoReportInterval
          currentForecastType = tempForecastType
          currentTimeFormat = tempTimeFormat
          currentThemeColor = colorMap[currentSelectedColorName] or "#0D47A1"
          
          savePreferences()

          if isChanged then
            local t = Toast.makeText(service, "Settings saved successfully", Toast.LENGTH_SHORT)
            t.show()
          end
          goBack()
          return
        end

        if elem.isCancelBtn then
          local isChanged = hasGeneralSettingsChanged()
          tempSelectedColorName = currentSelectedColorName
          tempSoundEnabled = currentSoundEnabled
          tempSoundVolume = currentSoundVolume
          tempDetectLocationEnabled = currentDetectLocationEnabled
          tempAutoReportEnabled = currentAutoReportEnabled
          tempAutoReportInterval = currentAutoReportInterval
          tempForecastType = currentForecastType
          tempTimeFormat = currentTimeFormat
          
          if isChanged then
            local t = Toast.makeText(service, "Settings cancelled", Toast.LENGTH_SHORT)
            t.show()
          end
          goBack()
          return
        end

        if elem.isUnitSaveBtn then
          local isChanged = hasUnitSettingsChanged()
          currentTempUnit = tempTempUnit
          currentVisUnit = tempVisUnit
          currentWindUnit = tempWindUnit
          currentPressUnit = tempPressUnit
          currentPrecipUnit = tempPrecipUnit
          
          savePreferences()

          if isChanged then
            local t = Toast.makeText(service, "Settings saved successfully", Toast.LENGTH_SHORT)
            t.show()
          end
          goBack()
          return
        end

        if elem.isUnitCancelBtn then
          local isChanged = hasUnitSettingsChanged()
          tempTempUnit = currentTempUnit
          tempVisUnit = currentVisUnit
          tempWindUnit = currentWindUnit
          tempPressUnit = currentPressUnit
          tempPrecipUnit = currentPrecipUnit
          
          if isChanged then
            local t = Toast.makeText(service, "Settings cancelled", Toast.LENGTH_SHORT)
            t.show()
          end
          goBack()
          return
        end

        if elem.isReportSaveBtn then
          local isChanged = hasReportSettingsChanged()
          for k, v in pairs(tempWeatherReport) do currentWeatherReport[k] = v end
          
          savePreferences()

          if isChanged then
            local t = Toast.makeText(service, "Settings saved successfully", Toast.LENGTH_SHORT)
            t.show()
          end
          goBack()
          return
        end

        if elem.isReportCancelBtn then
          local isChanged = hasReportSettingsChanged()
          for k, v in pairs(currentWeatherReport) do tempWeatherReport[k] = v end
          
          if isChanged then
            local t = Toast.makeText(service, "Settings cancelled", Toast.LENGTH_SHORT)
            t.show()
          end
          goBack()
          return
        end

        if elem.isUpdateUserBtn then
          local editField = activeEditTexts["new_username_input"]
          local newName = editField and tostring(editField.getText()):match("^%s*(.-)%s*$") or ""

          if newName == "" then
            local t = Toast.makeText(service, "Username is required", Toast.LENGTH_SHORT)
            t.show()
            return
          end

          savedUsername = newName
          userData.username = newName
          savePreferences()

          local t = Toast.makeText(service, "Username updated successfully", Toast.LENGTH_SHORT)
          t.show()
          goBack()
          return
        end

        if id == 2 and elem.targetId == 3 then
          local editField = activeEditTexts["username_input"]
          local enteredName = editField and tostring(editField.getText()):match("^%s*(.-)%s*$") or ""

          if enteredName == "" then
            local t = Toast.makeText(service, "Username is required", Toast.LENGTH_SHORT)
            t.show()
            return
          end
          savedUsername = enteredName
          userData.username = enteredName
          savePreferences()
        end

        if id == 3 and elem.targetId == 4 then
          local t = Toast.makeText(service, "Welcome " .. userData.username .. "!", Toast.LENGTH_SHORT)
          t.show()
          navStack = {}
        end

        if elem.targetId == 0 then
          if dlg then dlg.dismiss() dlg = nil end
          navStack = {}
        elseif elem.targetId and windows[elem.targetId] then
          showScreen(elem.targetId, false)
        end
      end)
      container.addView(b)

    elseif elem.type == "textview" then
      local t = TextView(service)
      if elem.isWelcome then
        local nameToShow = (savedUsername ~= "" and savedUsername) or "User"
        t.setText("Hello " .. nameToShow .. ", your account has been successfully logged in.")
      elseif elem.isModeLabel then
        if id == 4 and showInlineWeather then
          t.setVisibility(View.GONE)
        else
          local modeText = currentDetectLocationEnabled and "Mode: Detect My Location" or "Mode: None"
          t.setText(modeText)
        end
      else
        t.setText(elem.text or "")
      end
      t.setTextColor(textColor)
      t.setPadding(10, 0, 10, 10)
      t.setFocusable(true)
      container.addView(t)
    end
  end

  dlg.setOnKeyListener(DialogInterface.OnKeyListener{
    onKey = function(dialog, keyCode, event)
      if keyCode == KeyEvent.KEYCODE_BACK and event.getAction() == KeyEvent.ACTION_UP then
        if id == 4 or id == 1 then
          if dlg then dlg.dismiss() dlg = nil end
          navStack = {}
        else
          goBack()
        end
        return true
      end
      return false
    end
  })

  dlg.show()
end

local function startApp()
  if savedUsername and savedUsername ~= "" then
    showScreen(4, false)
  else
    showScreen(1, false)
  end
end

updater.checkUpdate(startApp)
